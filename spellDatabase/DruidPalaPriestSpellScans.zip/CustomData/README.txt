Priests:

Missing: 
Searing Shot (Night Elf Racial)
Chastise 

Paladin:
Missing in #1: 
- Holy Shock
- Blessing of Sanctuary
- Greater Blessing of Sanctuary
- Seal of Command
- Repentance
- Greater Blessing of Kings
- Blessing of Kings

Missing in #2:
- Blessing of Sanctuary
- Greater Blessing of Sanctuary
- Seal of Command
- Repentance
- Greater Blessing of Kings
- Blessing of Kings
- Holy Shield
- Bulwark of the Righteous

Missing in #3:
- Holy Shock
- Bulwark
- Holy Shield
- Repentance

Druids:

Should have gotten all

